<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class QuestionsController extends Controller
{

    public function FunctionName(Type $var = null)
    {
        # code...
    }
    
}
