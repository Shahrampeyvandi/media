<?php

namespace App\Http\Controllers\Panel;

use Illuminate\Http\Request;
use App\Models\Contents\Posts;
use App\Models\Contents\Comments;
use App\Models\Contents\CommentsLikes;
use App\Models\Members\Members;
use App\Models\Students\Student;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index()
    {
        $messages = [];
        $member = auth()->user();
        if ($member->group == 'admin') {
            $countfilms = Posts::where('categories_id', 1)->count();
            $countanimations = Posts::where('categories_id', 2)->count();
            $countclips = Posts::where('categories_id', 3)->count();
            $countmusics = Posts::where('categories_id', 4)->count();
            $countpodcasts = Posts::where('categories_id', 5)->count();
            $countlearnings = Posts::where('categories_id', 6)->count();
            $countcomments = Comments::all()->count();
        } else {
            $countfilms = Posts::where('members_id', $member->id)->where('categories_id', 1)->count();
            $countanimations = Posts::where('members_id', $member->id)->where('categories_id', 2)->count();
            $countclips = Posts::where('members_id', $member->id)->where('categories_id', 3)->count();
            $countmusics = Posts::where('members_id', $member->id)->where('categories_id', 4)->count();
            $countpodcasts = Posts::where('members_id', $member->id)->where('categories_id', 5)->count();
            $countlearnings = Posts::where('members_id', $member->id)->where('categories_id', 6)->count();
            $countcomments = Comments::where('members_id', $member->id)->count();
        }


        $comments=Comments::all();
        $from= date("Y-m-01 00:00:00");
        $to=date("Y-m-29 23:59:59");
        $likebefore=0;   
        $disikebefore=0;

        $mostlikeid=1;
        $mostdislikeid=1;
        foreach($comments as $comment){

            $like=CommentsLikes::wherebetween('created_at',[$from,$to])->where('comments_id',$comment->id)->where('score','like')->count();
            $dislike=CommentsLikes::wherebetween('created_at',[$from,$to])->where('comments_id',$comment->id)->where('score','dislike')->count();

            if($like > $likebefore){
                $mostlikeid=$comment->id;
            }

            if($dislike > $disikebefore){
                $mostdislikeid=$comment->id;
            }

        }

        $mostlikedcomment=Comments::whereId($mostlikeid)->first();
        $mostdislikedcomment=Comments::whereId($mostdislikeid)->first();

    

        return view('Panel.Dashboard', compact(['countfilms', 'countanimations', 'countclips', 'countmusics', 'countpodcasts', 'countlearnings', 'messages','countcomments','mostlikedcomment','mostdislikedcomment']));
    }

    public function UploadFile()
    {
        $member=auth()->user();
        return view('Panel.UploadFile',compact('member'));
    }

    public function SubmitUploadFile(Request $request)
    {
        


        $validator = Validator::make($request->all(), [
            'file' => 'mimes:avi,mp4,mp3,mpga,mkv,3gp|required',
            'pic' => 'nullable|mimes:jpeg,png,jpg',
          
        ]);
    
        if ($validator->fails()) {
            return response()->json(
                ['errors' => 'فایل دارای فرمت نامعتبر میباشد']
                , 200);
        }
        
        if(!is_null($request->subtitle) && $request->file('subtitle')->getClientOriginalExtension() !== "vtt"){
            return response()->json(
                ['errors' => 'فایل زیر نویس باید دارای فرمت vtt باشد']
                , 200);
        }
        
       
        // $rules = array(
        //     'file' => 'mimes:avi,mp4,mp3,mkv,3gp|required',
        //     'pic' => 'mimes:jpeg,png,jpg'

        // );

        // $validator = Validator::make($request->all(), $rules);
        // if ($validator->fails()) {
        //     // Redirect or return json to frontend with a helpful message to inform the user 
        //     // that the provided file was not an adequate type
        //     return response()->json([
        //         'error' => $validator->errors()->getMessages()]
        //         , 400);
        // }



        // Upload path
        $destinationPath = "files/$request->title";
        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }
        $extension = $request->file('file')->getClientOriginalExtension();
        // Valid extensions

        $fileName = 'file_' . time() . '.' . $extension;
        $request->file('file')->move($destinationPath, $fileName);
        $filePath = "files/$request->title/$fileName";
        if ($request->hasFile('pic')) {
            
            $picextension = $request->file('pic')->getClientOriginalExtension();
            $fileName = 'pic_' . time() . '.' . $picextension;
            $request->file('pic')->move($destinationPath, $fileName);
            $picPath = "files/$request->title/$fileName";
        }else{
            $picPath='';
        }
        if ($request->hasFile('subtitle')) {
            
            $picextension = $request->file('subtitle')->getClientOriginalExtension();
            $fileName = 'subtitle_' . time() . '.' . $picextension;
            $request->file('subtitle')->move($destinationPath, $fileName);
            $subTitle = "files/$request->title/$fileName";
        }else{
            $subTitle='';
        }
        if($request->type == 4 || $request->type==5){

            $media='audio';
        }else{
            $media='video';

        }
        $post = new Posts();
        $post->title = $request->title;
        $post->desc = $request->desc;
        $post->picture = $picPath;
        $post->content_link = $filePath;
        $post->categories_id = $request->type;
        $post->languages_id = $request->lang;
        $post->subjects_id = $request->subject;
        $post->levels_id = $request->level;
        $post->media = $media;
        $post->duration = $request->duration;
        $post->type = 'free';
        $post->price = 0;
        $post->members_id = auth()->user()->id;
        $post->subtitle = $subTitle;
        $post->otheroninformation = $request->desc2;
        $post->views = 0;
        if(auth()->user()->ability == 'admin' || auth()->user()->ability == 'mid-level-admin'){
            $post->confirmed = 1;
        }
        $post->notystatus = 0; // not read notification
        
        $post->save();
        return response()->json(
            ['success' => 'فایل با موفقیت آپلود شد']
            , 200);
    }

    public function Profile()
    {

        $member = auth()->user();


        return view('Panel.Profile',compact('member'));
    }

    public function ProfileSave(Request $request)
    {
      

        $validator = Validator::make($request->all(), [
            'user_name' => 'required',
            'user_family' => 'required',
            'username' => 'required',


        ]);
    
      

        // if($request->user_pass){

        //     $validator = Validator::make($request->all(), [
            
        //         'user_pass' => 'min:6|required_with:password_confirmation|same:password_confirmation',
        //         'confirm_user_pass' => 'min:6'
              
        //     ]);

        // }
            
        if ($validator->fails()) {
            return back();
        }
   
        //dd($request);
        $member = auth()->user();


        if ($request->hasFile('user_profile')) {

        $destinationPath = "files/members".$member->id;
        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }
        $extension = $request->file('user_profile')->getClientOriginalExtension();
        // Valid extensions

        $fileName = 'avatar_' . time() . '.' . $extension;
        $request->file('user_profile')->move($destinationPath, $fileName);
        $filePath = "$destinationPath/$fileName";
            
        $member->avatar=$filePath;
        }

        $member->firstname=$request->user_name;
        $member->lastname=$request->user_family;

        if($request->user_pass){

            $member->password= Hash::make($request->user_pass);
        }

        $member->email=$request->user_email;

        $member->username=$request->username;

        $member->age=$request->age;

        $member->years=$request->years;
        $member->history=$request->history;
        $member->books=$request->books;

        $member->update();

        return back();
    }
}
