<?php

namespace App\Http\Controllers\Panel;

use Illuminate\Http\Request;
use App\Models\Students\Student;
use App\Http\Controllers\Controller;
use App\Models\Members\Members;
use App\Models\Contents\Posts;
use App\Models\SlideShow\Slideshow;
use Illuminate\Support\Facades\Validator;

class SlideshowController extends Controller
{

    public function Index(){

        $slideshows=Slideshow::all();

        return view('Panel.SlideShow',compact('slideshows'));
        }


        public function Submit(Request $request){

            $slideshows=Slideshow::all();

    
            return view('Panel.Members',compact('slideshows'));
            }

            public function Delete(Request $request){

                $slideshows=Slideshow::find($request->id);

                $slideshow->delete();
        
                return response()->json(
                    'deleted'
                    , 200);
                               
                }
}