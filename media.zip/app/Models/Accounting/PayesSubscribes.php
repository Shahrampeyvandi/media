<?php

namespace App\Models\Accounting;

use Illuminate\Database\Eloquent\Model;

class PayesSubscribes extends Model
{
    //
}
