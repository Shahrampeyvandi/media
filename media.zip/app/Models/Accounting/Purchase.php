<?php

namespace App\Models\Accounting;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    //
}
