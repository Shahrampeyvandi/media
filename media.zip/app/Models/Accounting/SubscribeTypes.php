<?php

namespace App\Models\Accounting;

use Illuminate\Database\Eloquent\Model;

class SubscribeTypes extends Model
{
    //
}
