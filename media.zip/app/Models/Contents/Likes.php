<?php

namespace App\Models\Contents;

use Illuminate\Database\Eloquent\Model;

class Likes extends Model
{
    protected $quarded= [];
}
