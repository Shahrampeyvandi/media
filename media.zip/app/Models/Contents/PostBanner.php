<?php

namespace App\Models\Contents;

use Illuminate\Database\Eloquent\Model;

class PostBanner extends Model
{
    protected $guarded = ['id'];
}
