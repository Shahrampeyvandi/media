<?php

namespace App\Models\Contents;

use Illuminate\Database\Eloquent\Model;

class Subjects extends Model
{
    //
}
