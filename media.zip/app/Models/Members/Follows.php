<?php

namespace App\Models\Members;

use Illuminate\Database\Eloquent\Model;

class Follows extends Model
{
    //
}
