<?php

namespace App\Models\Notifications;

use Illuminate\Database\Eloquent\Model;

class Notifications extends Model
{
    //
}
