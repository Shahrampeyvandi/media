<?php

namespace App\Models\SlideShow;

use Illuminate\Database\Eloquent\Model;

class Slideshow extends Model
{
    //
}
