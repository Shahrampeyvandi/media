@extends('layout.Main.template')

@section('content')

<div class="col-md-12 p-3">
    
    <div class="tab-contents clear mx-2">
        <div id="" class="">
            <div id="staticContainer">
                <div class="rules-section  grey lighten-4  p-3">
                   {!! $content !!}
                </div>    
            </div>
        </div>
    </div>
</div>
@endsection