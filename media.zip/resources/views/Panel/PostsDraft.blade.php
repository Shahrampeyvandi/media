@extends('layout.Panel.temp')

@section('content')
<div id="popup1" class="overlay">
    <div class="popup">

        <a class="close" href="#">&times;</a>
        <div class="content">
            <form id="" action="{{route('Panel.Posts.Reject.Submit')}}" method="get">
                @csrf
               
                <div class="mt-5 pr-2">
                    <h5 class="modal-title  pt-1 mb-2" id="exampleModalLabel">اخطار</h5>
                    <div class="form-group col-md-12">
                        <input type="hidden" id="post-id" name="post_id" value="">
                      
                       
                    </div>
                    

            <label for="user_pass" class="col-form-label"><span class="text-danger">*</span> دلیل عدم تایید: </label>
              <textarea type="text" class="form-control" rows="3" name="reason" id="reason"></textarea>
                </div>
               
                <div class="form-group  float-left mt-1 ">

                    <button type="submit" class="btn btn-sm btn-danger ">عدم تایید </button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div>

            <a href="{{route('Panel.Posts.Unconfirmed')}}" @if (request()->path() == "panel/allposts/unconfirmed")
                class="btn btn-info" @else class="btn btn-light"  @endif>درانتظار تایید</a>
            <a href="{{route('Panel.Posts.Rejected')}}" @if (request()->path() == "panel/allposts/rejected")
                class="btn btn-info" @else class="btn btn-light"  @endif>تایید نشده</a>


            <a href="#"></a>
        </div>
        <hr>
    </div>
</div>

<div class="col-sm-9 col-sm-offset-3 col-md-12  ">
    <div class="wpb_wrapper py-3">
        <h2 class="  mt-15 mb-15 title__divider title__divider--line" style="margin-right: 0px;"><span
                class="title__divider__wrapper">پست ها<span class="line brk-base-bg-gradient-right"></span>
            </span></h2>

    </div>
    <div style="overflow-x: auto;">
        <table id="example1" class="table table-striped  table-bordered">
            <thead class="grey lighten-1 text-white">
                <tr>
                    <th>ردیف</th>
                    <th> نام پست</th>
                    <th>دسته بندی</th>
                    <th>زبان</th>
                    <th>سطح</th>
                    <th>موضوع</th>
                    <th>نویسنده</th>
                    <th>تاریخ ثبت</th>
                    <th>وضعیت</th>
                 
                    <th>عملیات</th>

                </tr>
            </thead>

            <tbody>
                @foreach($posts as $key=>$post)
                <tr>
                    <td>{{$key+1}}</td>
                    <td>
                    <a class="text-primary" href="{{route('ShowItem',$post->id)}}">
                    {{$post->title}}
                    </a>
                    </td>
                    <td>{{$post->categories->name}}</td>
                    <td>{{$post->languages->name}}</td>
                    <td>{{$post->levels->name}}</td>
                    <td>{{$post->subjects->name}}</td>
                    <td>{{$post->members->username}}</td>
                    <td>{{\Morilog\Jalali\Jalalian::forge($post->created_at)->format('%d %B %Y')}}</td>
                    @switch($post->confirmed)
                    @case(0)
                    <td>در انتظار تایید</td>
                    <td>
                        <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                            <a href="{{route('Panel.Posts.Confirm.Submit',$post->id)}}"
                                class=" btn btn-primary btn-sm m-0">تایید</a>
                            <a data-id="{{$post->id}}" class="post--delete btn btn-warning btn-sm m-0">رد</a>
                        </div>
                    </td>
                    @break
                    @case(1)
                    <td>تایید شده</td>
                    <td>رد</td>
                    @break
                    @case(2)
                    <td>تایید نشده
                    به علت 
                    {{$post->rejectreason}}</td>
                    <td>تایید</td>
                    @break
                    @endswitch


                    @endforeach


            </tbody>
        </table>
    </div>
    <div style="text-align: center">

    </div>
</div>
@endsection
@section('css')

@endsection

@section('js')


@endsection