@extends('layout.Panel.temp')

@section('content')
<div class="col-sm-9 col-sm-offset-3 col-md-12  ">
    <div class="wpb_wrapper py-3">
        <h2 class="  mt-15 mb-15 title__divider title__divider--line"
            style="margin-right: 0px;"><span class="title__divider__wrapper"> دنبال کنندگان من<span
                    class="line brk-base-bg-gradient-right"></span>
            </span></h2>
     
    </div>
    <div style="overflow-x: auto;">
        <table id="example1" class="table table-striped  table-bordered">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>تصویر</th>
                <th style="width: 600px"> تیتر</th>
                <th>لینک</th>
                <th>تاریخ ثبت</th>
                <th>عملیات</th>

            </tr>
            </thead>

            <tbody>
            @foreach($slideshows as $key=>$slideshow)
            <tr>
            <td>{{$key+1}}</td>
            <td><img src="{{route('BaseUrl')}}//{{$slideshow->banner}}" style="width:300px;"></td>
            <td>{{$slideshow->title}}</td>
            <td>{{$slideshow->link}}</td>
            <td>{{\Morilog\Jalali\Jalalian::forge($slideshow->created_at)->format('%d %B %Y')}}</td>
            <td>
             <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                          
                            <a data-id="{{$slideshow->id}}" class="btn--delete btn btn-warning btn-sm m-0">حذف</a>
                        </div></td>

           </tr>
            @endforeach
         

          
          
            </tbody>
        </table>
    </div>
    <div style="text-align: center">
        
    </div>
</div>
@endsection
@section('css')
   
@endsection

@section('js')


@endsection