<div class="row">
    <div class="col-md-12">
        <h4 class="mb-3">پادکست ها</h4>
    </div>
</div>

<div class="row">
    <div style="width:230px;" class="mx-3">

        <div class="card radius shadowDepth1 o-hidden">
            <span class="subscribe-label position-absolute">منتشر شده</span>

            <div class="card__image border-tlr-radius">
                <img src="<?php echo e(asset('assets/images/record.png')); ?>" alt="image" class="border-tlr-radius">
            </div>
    
            <div class="card__content card__padding">
                <div class="card__share">
    
    
                    <a id="" class=" share-icon" href="#"><i class="fa fa-caret-square-left"></i></a>
                </div>
    
    
    
                <article class="card__article mt-2">
                    <h2><a href="#">عنوان پادکست</a></h2>
    
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus
                        harum...</p>
                </article>
            </div>
    
            <div class="card__action">
    
                <div class="card__author">
    
                    <a href="#">مربوط به : علی محمدی</a>
                </div>
            </div>
            <div class="card__meta d-flex justify-content-between p-2">
                <a href="#">دسته بندی زبان</a>
                <span>11 بهمن 1398</span>
            </div>
        </div>
    
    </div>
</div><?php /**PATH C:\xampp\htdocs\media\resources\views/Panel/Components/subscribeaudios.blade.php ENDPATH**/ ?>