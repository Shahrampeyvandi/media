

<?php $__env->startSection('content'); ?>

<div class="col-md-12 p-3">
    
    <div class="tab-contents clear mx-2">
        <div id="" class="">
            <div id="staticContainer">
                <div class="rules-section  grey lighten-4  p-3">
                   <?php echo $content; ?>

                </div>    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.Main.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\media\resources\views/Main/contactus.blade.php ENDPATH**/ ?>