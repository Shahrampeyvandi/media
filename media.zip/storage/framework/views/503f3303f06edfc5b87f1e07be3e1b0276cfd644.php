<header class="container d-none d-md-block">
    <div class="row">
        <div class="col-md-12">
            <ul class="stepper stepper-horizontal">

                <li class="active">
                    <a href="#!" style="padding: 0.5rem;">
                        <span style="width: 50px;height: 50px;padding-top: 7px;padding-left: 10px;padding-right: 10px;" class="circle">۱</span>
                        <span class="label">وارد کردن اطلاعات</span>
                    </a>
                </li>
                <li class="active">
                    <a href="#!" style="padding: 0.5rem;">
                        <span style="width: 50px;height: 50px;padding-top: 7px;padding-left: 10px;padding-right: 10px;" class="circle">۲</span>
                        <span class="label">تایید اطلاعات</span>
                    </a>
                </li>
                <li class="active">
                    <a href="#!" style="padding: 0.5rem;">
                        <span style="width: 50px;height: 50px;padding-top: 7px;padding-left: 10px;padding-right: 10px;" class="circle">۳</span>
                        <span class="label">اطلاعات شخصی</span>
                    </a>
                </li>



            </ul>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\media\resources\views/Includes/Login/Header.blade.php ENDPATH**/ ?>