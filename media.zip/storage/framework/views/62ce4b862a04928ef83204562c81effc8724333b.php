

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <section id="" style="    padding: 40px 0;" class="list-item li px-3" data-list="slider">
            <div class="wpb_wrapper py-3">
                <h2 class="font__family-open-sans font__size-20  mt-15 mb-15 title__divider title__divider--line"
                    style="margin-right: 0px;"><span class="title__divider__wrapper">ویدیو ها<span
                            class="line brk-base-bg-gradient-right"></span>
                    </span></h2>
                <a href="#">   
                </a>
            </div>
            <div class="container">
                <div class="row">
                    <?php
                        dd(request()->path() );
                    ?>
                    <?php if(request()->route()->getName() == 'UnsubscribeVideos'): ?>
                    <?php $__env->startComponent('Main.components.video',['videos' => $posts]); ?>
                        
                    <?php if (isset($__componentOriginald7ef89c74a2a6fd287c782bf336d87ee05cae3ba)): ?>
<?php $component = $__componentOriginald7ef89c74a2a6fd287c782bf336d87ee05cae3ba; ?>
<?php unset($__componentOriginald7ef89c74a2a6fd287c782bf336d87ee05cae3ba); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    <?php endif; ?>
                   

                </div>
            </div>



        </section>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.Main.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\media\resources\views/Main/ShowVideos.blade.php ENDPATH**/ ?>