<div class="row">
    <div class="col-md-12">
        <h4 class="mb-3">پادکست ها</h4>
    </div>
</div>

<div class="row">
<div class="col-sm-9 col-sm-offset-3 col-md-12  ">
   
    <div style="overflow-x: auto;">
        <table id="example1" class="table table-striped  table-bordered">
            <thead>
            <tr>
                <th> ش</th>
                <th> عنوان</th>
                <th style="width: 600px"> دلیل عدم تایید</th>
                <th>تاریخ ارسال</th>
                <th>وضعیت</th>
            </tr>
            </thead>

            <tbody>
           <tr>
               <td>ds</td>
               <td>sdf</td>
               <td>sdf</td>
               <td>sdf</td>
               <td>sdf</td>
           </tr>
           <tr>
            <td>sdf</td>
            <td>sd</td>
            <td>sdf</td>
            <td>sd</td>
            <td>sdf</td>
        </tr>
            </tbody>
        </table>
    </div>
    <div style="text-align: center">
        
    </div>
</div>
</div><?php /**PATH C:\xampp\htdocs\media\resources\views/Panel/Components/unsubscribeaudios.blade.php ENDPATH**/ ?>