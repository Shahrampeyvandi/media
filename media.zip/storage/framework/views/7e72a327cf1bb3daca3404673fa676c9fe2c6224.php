

<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-md-12  ">
    <div class="wpb_wrapper py-3">
        <h2 class="  mt-15 mb-15 title__divider title__divider--line"
            style="margin-right: 0px;"><span class="title__divider__wrapper"> دنبال کنندگان من<span
                    class="line brk-base-bg-gradient-right"></span>
            </span></h2>
     
    </div>
    <div style="overflow-x: auto;">
        <table id="example1" class="table table-striped  table-bordered">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>تصویر</th>
                <th style="width: 600px"> تیتر</th>
                <th>لینک</th>
                <th>تاریخ ثبت</th>
                <th>عملیات</th>

            </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $slideshows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slideshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($key+1); ?></td>
            <td><img src="<?php echo e(route('BaseUrl')); ?>//<?php echo e($slideshow->banner); ?>" style="width:300px;"></td>
            <td><?php echo e($slideshow->title); ?></td>
            <td><?php echo e($slideshow->link); ?></td>
            <td><?php echo e(\Morilog\Jalali\Jalalian::forge($slideshow->created_at)->format('%d %B %Y')); ?></td>
            <td>
             <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                          
                            <a data-id="<?php echo e($slideshow->id); ?>" class="btn--delete btn btn-warning btn-sm m-0">حذف</a>
                        </div></td>

           </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

          
          
            </tbody>
        </table>
    </div>
    <div style="text-align: center">
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.Panel.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\media\resources\views/Panel/SlideShow.blade.php ENDPATH**/ ?>