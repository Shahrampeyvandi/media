

<?php $__env->startSection('content'); ?>

<div class="col-md-12 p-3">
    <div class="tab-contents clear">

        <div id="" class="">
    
    
            <div id="staticContainer">
                <div class="wpb_wrapper py-3">
                    <h2 class="font__family-open-sans font__size-20  mt-15 mb-15 title__divider title__divider--line"
                        style="margin-right: 0px;"><span class="title__divider__wrapper">قوانین سایت<span
                                class="line brk-base-bg-gradient-right"></span>
                        </span></h2>
    
                </div>
                <div class="rules-section stylish-color text-white-50 p-3">
    
    
                    <p class="paragraph text-white">قوانینی که باید اساتید رعایت نمایند</p>
                    <ul class="disc text-white-50">
                        <li>رعایت حقوق ناشر و مولف</li>
                        <li>دلخراش و آزار دهنده نبودن</li>
                        <li>مغایرت نداشتن با شئونات اخلاقی و عرف جامعه</li>
                        <li>اهانت آمیز نبودن به مقامات سیاسی</li>
                        <li>نداشتن موزیک متن غیر مجاز</li>
                        <li>عدم ایجاد تنش و التهاب سیاسی در سایت</li>
                        <li>عدم تمسخر یک شهروند</li>
                        <li>اهانت آمیز نبودن به اقلیت های قومی و مذهبی</li>
                    </ul>
                    <p class="text-white-50"> با استناد به ماده 74 قانون تجارت الکترونیک مصوب 17/10/1382 مجلس شورای اسلامی و
                        با عنایت به اینکه سایت آپارات مصداق بستر مبادلات الکترونیکی صوتی و تصویر است ، مسئولیت نقض حقوق
                        تصریح شده مولفان در قانون فوق از قبیل تکثیر ، اجرا و توزیع و یا هر گونه محتوی خلاف قوانین کشور ایران
                        بر عهده کاربران است.</p>
                    <p class="text-white-50">پس از بارگذاری ویدیو، حقوق مربوط به انتشار، حذف و ویرایش ویدیوهای بارگذاری شده
                        نزد آپارات محفوظ خواهد ماند.</p>
                    <p class="text-white-50">سایت آپارات تابع کلیه قوانین موضوعه کشور به خصوص قانون تجارت الکترونیک است لذا
                        نقض هر رفتاری که متضمن نقض هریک از قوانین کشور باشد مجرمانه تلقی میگردد و قابل پیگیری است .</p>
                   
                </div>
                <div class="rules-section stylish-color text-white-50 p-3 my-5">
    
    
                    <p class="paragraph text-white">قوانینی که باید دانش آموزان رعایت نمایند</p>
                    <ul class="disc text-white-50">
                        <li>رعایت حقوق ناشر و مولف</li>
                        <li>دلخراش و آزار دهنده نبودن</li>
                        <li>مغایرت نداشتن با شئونات اخلاقی و عرف جامعه</li>
                        <li>اهانت آمیز نبودن به مقامات سیاسی</li>
                        <li>نداشتن موزیک متن غیر مجاز</li>
                        <li>عدم ایجاد تنش و التهاب سیاسی در سایت</li>
                        <li>عدم تمسخر یک شهروند</li>
                        <li>اهانت آمیز نبودن به اقلیت های قومی و مذهبی</li>
                    </ul>
                    <p class="text-white-50"> با استناد به ماده 74 قانون تجارت الکترونیک مصوب 17/10/1382 مجلس شورای اسلامی و
                        با عنایت به اینکه سایت آپارات مصداق بستر مبادلات الکترونیکی صوتی و تصویر است ، مسئولیت نقض حقوق
                        تصریح شده مولفان در قانون فوق از قبیل تکثیر ، اجرا و توزیع و یا هر گونه محتوی خلاف قوانین کشور ایران
                        بر عهده کاربران است.</p>
                    <p class="text-white-50">پس از بارگذاری ویدیو، حقوق مربوط به انتشار، حذف و ویرایش ویدیوهای بارگذاری شده
                        نزد آپارات محفوظ خواهد ماند.</p>
                    <p class="text-white-50">سایت آپارات تابع کلیه قوانین موضوعه کشور به خصوص قانون تجارت الکترونیک است لذا
                        نقض هر رفتاری که متضمن نقض هریک از قوانین کشور باشد مجرمانه تلقی میگردد و قابل پیگیری است .</p>
                   
                </div>
    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.Main.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\media\resources\views/Main/policies.blade.php ENDPATH**/ ?>