<div class="row">
    <div class="col-md-12">
        <h4 class="mb-3">کلیپ ها</h4>
    </div>
</div>

<div class="row">
    <div class="col-md-3">
        <div class="thumbnail-movie o-hidden thumbnail-serial position-relative">

            <div class="thumb-wrapper">

                <a class="thumb">
                    <div class="abs-fit">
                        <img src=" <?php echo e(asset('assets/images/business.jpg')); ?> " alt="خانه کاغذی" aria-label="خانه کاغذی"
                            class=" thumb-image">
                    </div>
                    <span class="subscribe-label position-absolute">منتشر شده</span>
                    <div class="tools">
                        <span class="badge-rate">
                            <span>96%</span>
                            <svg class="icon icon-thumb-up d-in v-m g-20 fs-1-2 ml-xxs" viewBox="0 0 24 24"
                                viewBox="viewBox=" 0 0 24 24"">
                                <use xlink:href="#si_thumb-up">
                                    <g id="si_thumb-up" data-viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0z" fill="none"></path>
                                        <path d="M0 0h24v24H0z" fill="none"></path>
                                        <path
                                            d="M9 21h9a1.987 1.987 0 0 0 1.84-1.22l3.02-7.05A1.976 1.976 0 0 0 23 12v-2a2.006 2.006 0 0 0-2-2h-6.31l.95-4.57.03-.32a1.505 1.505 0 0 0-.44-1.06L14.17 1 7.58 7.59A1.987 1.987 0 0 0 7 9v10a2.006 2.006 0 0 0 2 2zM9 9l4.34-4.34L12 10h9v2l-3 7H9z">
                                        </path>
                                        <path transform="translate(1 9)" d="M0 0h4v12H0z"></path>
                                    </g>
                                </use>
                            </svg> </span>
                        <span class="badge-rate">
                            <span>20:00</span>
                            <i class="fa fa-clock pl-1"></i>
                        </span>
                    </div>
                </a>
            </div>
            <div class="position-relative p-2">

                <a href="<?php echo e(route('ShowItem',['id' => '1'])); ?>" title="خانه کاغذی" class="title title d-block mb-2"><span>خانه
                        کاغذی</span></a>
                <p class=""><span>ایجاد شده توسط: ادمین</span></p>
                <p class=""><span>موضوع: </span><span>مکالمه</span></p>
                <p class=""><span>زبان: </span><span>انگلیسی</span></p>

                <ul class="meta-tags d-b w-100 mt-xs  pb-2">
                    <li class="meta d-in light-60 dark-110">2017</li>
                    <li class="meta d-in light-60 dark-110">اسپانیا</li>

                    <li class="meta d-in light-60 dark-110">اکشن</li>
                    <li class="meta d-in light-60 dark-110">پلیسی معمایی</li>
                </ul>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\media\resources\views/Panel/Components/subscribevideos.blade.php ENDPATH**/ ?>