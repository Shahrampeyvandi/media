$(document).ready(function(){
    $('.button__').click(function(e){
        e.preventDefault()
        let id = $(this).data('id')
       $('#comment_id').attr('value',id)
     $('.overlay').css({  'visibility': 'visible',
         'opacity': '1',
         'z-index': '10',})
    })
 
    $('.close').click(function(e){
     e.preventDefault()
     $('.overlay').css({  'visibility': 'hidden',
         'opacity': '0',
         'z-index': '10',})
    })

    $('.btn--delete').click(function(e){
        e.preventDefault()
        let id = $(this).data('id')
       $('#comment_id').attr('value',id)
     $('.overlay').css({  'visibility': 'visible',
         'opacity': '1',
         'z-index': '10',})
    })
 
    $('.close').click(function(e){
     e.preventDefault()
     $('.overlay').css({  'visibility': 'hidden',
         'opacity': '0',
         'z-index': '10',})
    })

    $('.post--delete').click(function(e){
        e.preventDefault()
        let id = $(this).data('id')
       $('#post-id').attr('value',id)
     $('.overlay').css({  'visibility': 'visible',
         'opacity': '1',
         'z-index': '10',})
    })

    $('#notif-link').click(function(e){
        e.preventDefault()
        $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
        $.ajax({ 
            url: 'readnoty',
            type: 'POST',
         
            dataType: 'JSON', 
            cache:false,
            success: function(res) {
            }
    });
    })

    $('.delete-post').click(function(e){
        e.preventDefault()
        let id = $(this).data('id')
        $('#post_id').attr('value',id)
        $('.overlay').css({  'visibility': 'visible',
        'opacity': '1',
        'z-index': '10',})
    })



    
})